import React from 'react'

const AboutUs = () => {
  return (
    <div>
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="Our-story">
              <h2>Our story</h2>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur odio aliquid asperiores ex quidem, deserunt odit temporibus culpa, voluptatibus magni mollitia recusandae non placeat deleniti vitae suscipit error voluptatum, facere facilis hic quisquam molestias totam quo. Corrupti, libero? Architecto adipisci labore dignissimos fugiat tenetur quae quod repellendus quos debitis eum?
                sit amet consectetur adipisicing elit. Pariatur odio aliquid asperiores ex quidem, deserunt odit temporibus culpa, voluptatibus magni mollitia recusandae non placeat deleniti vitae suscipit error voluptatum, facere facilis hic quisquam molestias totam quo. Corrupti, libero? Architecto adipisci labore dignissimos fugiat tenetur quae quod repellendus quos debitis eum?
                sit amet consectetur adipisicing elit. Pariatur odio aliquid asperiores ex quidem, deserunt odit temporibus culpa, voluptatibus magni mollitia recusandae non placeat deleniti vitae suscipit error voluptatum, facere facilis hic quisquam molestias totam quo. Corrupti, libero? Architecto adipisci labore dignissimos fugiat tenetur quae quod repellendus quos debitis eum?
                facilis hic quisquam molestias totam quo. Corrupti, libero? Architecto adipisci labore dignissimo
              </p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="our-img">
              <img src="/assets/img/images/portfolio-1.jpg" alt="" />
            </div>
          </div>
        </div>
        <div class="row mt-5">
          <div class="col-md-4">
            <div class="our-img">
              <img src="/assets/img/images/portfolio-5.jpg" alt="" />
            </div>
          </div>
          <div class="col-md-8">
            <div class="Our-story">
              <h2>Our story</h2>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur odio aliquid asperiores ex quidem, deserunt odit temporibus culpa, voluptatibus magni mollitia recusandae non placeat deleniti vitae suscipit error voluptatum, facere facilis hic quisquam molestias totam quo. Corrupti, libero? Architecto adipisci labore dignissimos fugiat tenetur quae quod repellendus quos debitis eum?
                sit amet consectetur adipisicing elit. Pariatur odio aliquid asperiores ex quidem, deserunt odit temporibus culpa, voluptatibus magni mollitia recusandae non placeat deleniti vitae suscipit error voluptatum, facere facilis hic quisquam molestias totam quo. Corrupti, libero? Architecto adipisci labore dignissimos fugiat tenetur quae quod repellendus quos debitis eum?
                sit amet consectetur adipisicing
                <p>Pariatur odio aliquid asperiores ex quidemelit. Pariatur odio aliquid asperiores ex quidem, deserunt odit temporibus culpa, voluptatibus magni mollitia recusandae non placeat deleniti vitae suscipit error voluptatum, facere facilis hic quisquam molestias totam quo. Corrupti, libero? Architecto adipisci labore dignissimos fugiat tenetur quae quod repellendus quos debitis eum?
                  sit amet consectetur adipisicing,</p>
                <br />
                  amet consectetur adipisicing elit. Pariatur odio aliquid asperiores ex quidem, deserunt odit temporibus culpa, voluptatibus magni mollitia recusandae non placeat deleniti vitae suscipit error voluptatum, facere facilis hic quisquam molestias totam quo. Corrupti, libero? Architecto adipisci labore dignissimos fugiat tenetur quae quod repellendus quos debitis eum?
                  sit amet consectetur adipisicing elit. Pariatur odio aliquid asperiores ex quidem,
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AboutUs