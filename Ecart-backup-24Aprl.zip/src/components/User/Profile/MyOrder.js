import React from 'react'

const MyOrder = () => {
  return (
    <div>MyOrder</div>
  )
}

export default MyOrder