import React from 'react'
import "./loder.css"

const Lodder = () => {
  return (
    <div className="loading">
    <div></div>
  </div>
  )
}

export default Lodder