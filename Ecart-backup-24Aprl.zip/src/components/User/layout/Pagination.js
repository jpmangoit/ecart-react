
import React from 'react'

const Pagination = (props) => {
  return (
    <div>Pagination</div>
  )
}

export default Pagination